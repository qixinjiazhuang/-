<?php
namespace AliyunMNS\Exception;

use AliyunMNS\Exception\MnsException;

class TopicNotExistException extends MnsException
{
}

?>
